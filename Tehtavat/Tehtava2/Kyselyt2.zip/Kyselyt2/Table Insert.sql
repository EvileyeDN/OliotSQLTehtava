﻿INSERT INTO Kirja(ID,Kirjan_Nimi,kustantaja,vuosi,sivu_maara)
Values(1,'office 2016','Docendo',2016,300);
INSERT INTO Kirja(ID,Kirjan_Nimi,kustantaja,vuosi,sivu_maara)
Values(2,'Windows 10','Docendo',2015,310);
INSERT INTO Kirja(ID,Kirjan_Nimi,kustantaja,vuosi,sivu_maara)
Values(3,'Outoa ohjelmointia','Docendo',2016,192);
INSERT INTO Kirja(ID,Kirjan_Nimi,kustantaja,vuosi,sivu_maara)
Values(4,'ipad käsikirja','WSOY',2016,290);
INSERT INTO Kirja(ID,Kirjan_Nimi,kustantaja,vuosi,sivu_maara)
Values(5,'Biteistä bisnestä','JKP',2014,237);