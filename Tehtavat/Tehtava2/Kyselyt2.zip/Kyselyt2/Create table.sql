﻿CREATE TABLE [dbo].[Kirja] (
    [ID] INT NOT NULL,
    [Kirjan_Nimi] char(50) NULL,
    [kustantaja] Char(50)  NULL,
    [vuosi]  INT  NULL,
    [sivu_maara]  INT  NULL
);

