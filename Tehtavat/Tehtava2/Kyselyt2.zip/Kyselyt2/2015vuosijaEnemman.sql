﻿SELECT ID, Kirjan_nimi,kustantaja,vuosi,sivu_maara
FROM Kirja
WHERE vuosi<=2015