﻿SELECT Nimi, PintaAla
FROM kaupungit
WHERE Nimi='Jyväskylä'