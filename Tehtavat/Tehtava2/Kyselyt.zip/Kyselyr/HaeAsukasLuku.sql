﻿SELECT Nimi, AsukasLuku
FROM kaupungit
WHERE AsukasLuku<200000