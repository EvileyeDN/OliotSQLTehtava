﻿UPDATE kaupungit
SET PintaAla=340
where Nimi='Tampere';