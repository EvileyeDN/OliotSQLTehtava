﻿Insert INTO kaupungit(Id, Nimi,AsukasLuku,PintaAla)
VALUES(1,'Helsinki',550000,184.5);
Insert INTO kaupungit(Id, Nimi,AsukasLuku,PintaAla)
VALUES(1,'Tampere',280000,523);
Insert INTO kaupungit(Id, Nimi,AsukasLuku,PintaAla)
VALUES(1,'Jyväskylä',120000,105);
Insert INTO kaupungit(Id, Nimi,AsukasLuku,PintaAla)
VALUES(1,'Oulu',220000,1410);