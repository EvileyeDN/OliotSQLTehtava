﻿SELECT Nimi, AsukasLuku
FROM kaupungit