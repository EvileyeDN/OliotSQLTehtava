﻿CREATE TABLE [dbo].[kaupungit] (
    [Id]         INT    NOT NULL,
    [Nimi]       CHAR (20)  NULL,
    [AsukasLuku] INT  NULL,
    [PintaAla]   FLOAT NULL,
);
