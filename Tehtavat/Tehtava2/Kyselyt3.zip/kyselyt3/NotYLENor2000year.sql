﻿Select Nimi
From elokuvat
WHERE Julkaisija!= 'YLEN' or Julkaisuvuosi=2000;