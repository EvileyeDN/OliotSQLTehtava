﻿Select Nimi
From elokuvat
WHERE Julkaisuvuosi>2000 and Kesto<60;