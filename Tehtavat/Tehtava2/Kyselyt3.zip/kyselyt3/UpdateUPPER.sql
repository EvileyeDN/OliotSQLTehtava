﻿UPDATE elokuvat
SET Julkaisija= UPPER(Julkaisija)