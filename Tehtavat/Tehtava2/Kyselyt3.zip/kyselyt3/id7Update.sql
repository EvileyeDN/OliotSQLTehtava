﻿UPDATE elokuvat
set Julkaisuvuosi=2011
WHERE ID=7