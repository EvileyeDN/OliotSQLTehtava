﻿SELECT Nimi
FROM elokuvat
ORDER BY Arvio DESC