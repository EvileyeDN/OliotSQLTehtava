﻿UPDATE elokuvat
SET Julkaisija='MTV'
where Julkaisija='MTV3';