﻿Select Nimi
From elokuvat
WHERE Nimi LIKE 's%' or Kesto>80;