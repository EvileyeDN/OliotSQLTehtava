﻿select count(1)
from elokuvat