﻿Select Nimi
From elokuvat
WHERE Julkaisija = 'YLE';