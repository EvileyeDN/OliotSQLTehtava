﻿SELECT AVG(Kesto)as avg
from elokuvat