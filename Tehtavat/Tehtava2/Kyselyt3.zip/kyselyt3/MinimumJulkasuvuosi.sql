﻿select Min(Julkaisuvuosi)
from elokuvat