﻿Select Nimi
From elokuvat
WHERE Julkaisija IN ('YLEN','BBC','MTV3');