﻿Select id,Nimi,Julkaisuvuosi,Kesto,Arvio,Julkaisija
FROM elokuvat
WHERE Kesto>160 AND Julkaisuvuosi BETWEEN 1998 AND 2007