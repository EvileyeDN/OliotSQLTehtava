﻿select max(Kesto)
from elokuvat