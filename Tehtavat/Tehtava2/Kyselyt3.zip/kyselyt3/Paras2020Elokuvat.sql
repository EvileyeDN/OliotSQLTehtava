﻿SELECT Nimi, Julkaisija
FROM elokuvat
WHERE Julkaisuvuosi=2020
ORDER BY Arvio DESC