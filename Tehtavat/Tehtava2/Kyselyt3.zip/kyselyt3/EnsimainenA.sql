﻿Select Nimi
From elokuvat
WHERE Nimi LIKE 'A%';